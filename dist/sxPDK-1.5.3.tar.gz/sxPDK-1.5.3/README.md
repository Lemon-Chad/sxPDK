# ShieldX PDK

The ShieldX PDK is a plugin development kit for the ShieldX Manager Discord Bot.

  - Easy access to bot data
  - Simple and easy to use functions
  - Infinite possibilites

# Usages

  - Program a custom plugin with the ShieldX PDK and discord.py
  - Submit it on the ShieldX Discord for bug testing and approval

